package fr.afrogeek.getthrconnet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GetthrconnetApplicationTests {

	@Test
	void contextLoads() {
	}

}
